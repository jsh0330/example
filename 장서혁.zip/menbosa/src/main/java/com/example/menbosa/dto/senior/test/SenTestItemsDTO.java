package com.example.menbosa.dto.senior.test;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class SenTestItemsDTO {
//    TEST_ITEM_ONE
//             , TEST_ITEM_TWO
//             , TEST_ITEM_THREE
//             , TEST_ITEM_FOUR
    private int testQuestNum;
    private String testItemOne;
    private String testItemTwo;
    private String testItemThree;
    private String testItemFour;
}
