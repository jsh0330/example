package com.example.menbosa.dto.senior.test;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class SenTestListDTO {
//    TEST_LIST_NUM
//             , TEST_LIST_NAME
//             , TEST_LIST_DIFFI
//             , TEST_LIST_AGE
    private int testListNum;
    private String testListName;
    private String testListDiffi;
    private String testListAge;
}
