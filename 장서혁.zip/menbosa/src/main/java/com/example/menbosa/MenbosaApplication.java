package com.example.menbosa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MenbosaApplication {

    public static void main(String[] args) {
        SpringApplication.run(MenbosaApplication.class, args);
    }

}
