package com.example.menbosa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MenbosaApplicationTests {

    @Test
    void contextLoads() {
    }

}
